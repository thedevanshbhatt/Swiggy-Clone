# Swiggy Clone
Tried to create a landing page of [swiggy.com](https://swiggy.com) using `React`. Work in progress..

Preview URL: https://swiggy-clone-23.web.app/

Screenshot:
<img width="952" alt="image" src="https://github.com/sriram23/swiggy-clone/assets/18396996/1c58ab14-cad5-4ce0-acd8-a4be51ea49bb">

